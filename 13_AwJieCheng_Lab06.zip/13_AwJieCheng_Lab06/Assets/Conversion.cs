﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System;

public class Conversion : MonoBehaviour
{
    public InputField Inputamount;
    public InputField amount;

    public Toggle USD;
    public Toggle JPY;

    public float SGDUSD = 0.76f;
    public float SGDYEN = 97.08f;

    float Amount;

    // Start is called before the first frame update
    void Start()
    {
        USD.isOn = false;
        JPY.isOn = false;


    }

    // Update is called once per frame
    public void Convert()
    {
        Amount = float.Parse(amount.text);

        if (USD.isOn == true)
        {
            Inputamount.text = "$" + (Amount * SGDUSD);
        }
        if (JPY.isOn == true)
        {
            Inputamount.text = "$" + (Amount * SGDYEN);
        }
    }
    public void clear()
    {
        USD.isOn = false;
        JPY.isOn = false;

        Inputamount.text = "";
        amount.text = "";
    }
}
