﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System;

public class Conversion : MonoBehaviour
{
    public InputField Inputamount;
    public InputField amount;

    public Toggle USD;
    public Toggle JPY;
    public Toggle RM;
    public Toggle EUR;
    public Toggle KRW;
    public Toggle TWD;

    public float SGDUSD = 0.76f;
    public float SGDYEN = 97.08f;
    public float SGDRM = 3.08f;
    public float SGDEUR = 0.63f;
    public float SGDKRN = 881.54f;
    public float SGDTWD = 20.73f;


    float Amount;

    // Start is called before the first frame update
    void Start()
    {
        USD.isOn = false;
        JPY.isOn = false;
        RM.isOn = false;
        EUR.isOn = false;
        KRW.isOn = false;
        TWD.isOn = false;



    }

    // Update is called once per frame
    public void Convert()
    {
        Amount = float.Parse(amount.text);

        if (USD.isOn == true)
        {
            Inputamount.text = "$" + (Amount * SGDUSD);
        }
        if (JPY.isOn == true)
        {
            Inputamount.text = "$" + (Amount * SGDYEN);
        }
        if (RM.isOn == true)
        {
            Inputamount.text = "$" + (Amount * SGDRM);
        }
        if (EUR.isOn == true)
        {
            Inputamount.text = "$" + (Amount * SGDEUR);
        }
        if (KRW.isOn == true)
        {
            Inputamount.text = "$" + (Amount * SGDKRN);
        }
        if (TWD.isOn == true)
        {
            Inputamount.text = "$" + (Amount * SGDTWD);
        }
    }
    public void clear()
    {
        USD.isOn = false;
        JPY.isOn = false;
        RM.isOn = false;
        EUR.isOn = false;
        KRW.isOn = false;
        TWD.isOn = false;


        Inputamount.text = "";
        amount.text = "";
    }
}
